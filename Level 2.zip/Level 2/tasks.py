from robocorp.tasks import task
from robocorp import browser
from RPA.HTTP import HTTP
from RPA.Tables import Tables
from RPA.PDF import PDF
from RPA.Images import Images
from RPA.Archive import Archive
from os import listdir,mkdir

@task
def order_robots_fromRobotSpareBin():
    """
    Orders robots from RobotSpareBin Industries Inc.
    Saves the order HTML receipt as a PDF file.
    Saves the screenshot of the ordered robot.
    Embeds the screenshot of the robot to the PDF receipt.
    Creates ZIP archive of the receipts and the images.
    """
    browser.configure(
        slowmo=100,
    )
    mkdir("output/receipts/")
    open_robot_order_website()
    input_orders()
    archive_receipts()

def open_robot_order_website():
    browser.goto("https://robotsparebinindustries.com/#/robot-order")
    
def get_orders():
    http = HTTP()
    http.download("https://robotsparebinindustries.com/orders.csv",overwrite=True)
    orders = Tables().read_table_from_csv("orders.csv",
                                          columns=["Order number","Head","Body","Legs","Address"])
    return orders
def input_orders():
    orders=get_orders()
    for order in orders:
        try:
            fill_the_form(order)
        except:
            page=browser.page()
            page.reload()
            fill_the_form(order)
        
            
def close_annoying_modal():
    page = browser.page()
    page.click("button:text('OK')")

def order_again():
    page = browser.page()
    page.click("button:text('Order another robot')")

def store_receipt_as_pdf(order_number):
    
    output_file=open("output/receipts/"+str(order_number)+".pdf",'x')
    
    output_file.close()
    return "output/receipts/"+str(order_number)+".pdf"

def screenshot_robot(order_number):
    page = browser.page()
    page.screenshot(path="output/screenshots/"+str(order_number)+".png")
    return "output/screenshots/"+str(order_number)+".png"

def embed_screenshot_to_receipt(screenshot,pdf_file):
    pdf=PDF()
    pdf.add_files_to_pdf(files=[screenshot],target_document=str(pdf_file))
    
def archive_receipts():
    archives="output/receipts/"
    zip_file=Archive()
    zip_file.archive_folder_with_zip(folder=archives,archive_name="output/receipts.zip")
    
def fill_the_form(order):
    close_annoying_modal()
    page=browser.page()
    page.select_option("#head",str(order["Head"]))
    if(str(order["Body"])=="1"):
        page.get_by_text('Roll-a-thor body').click()
    elif(str(order["Body"])=="2"):
        page.get_by_text('Peanut crusher body').click()
    elif(str(order["Body"])=="3"):
        page.get_by_text('D.A.V.E body').click()
    elif(str(order["Body"])=="4"):
        page.get_by_text('Andy Roid body').click()
    elif(str(order["Body"])=="5"):
        page.get_by_text('Spanner mate body').click()
    elif(str(order["Body"])=="6"):
        page.get_by_text('Drillbit 2000 body').click()
    page.get_by_placeholder("Enter the part number for the legs").fill(str(order["Legs"]))
    
    page.fill('#address',str(order["Address"]))
    page.click("button:text('Order')")
    page=browser.page()
    if(page.get_by_text('Order another robot').is_visible(timeout=1000) is False):
        # page=browser.page()
        # page.get_by_title()
        # print(str(page.get_by_text("button:text('Order')").is_visible(timeout=1000))+'\n')
        # sleep(1)
        page.click("button:text('Order')")
        
    screenshot=screenshot_robot(order["Order number"])
    order_again()
    embed_screenshot_to_receipt(screenshot,store_receipt_as_pdf(order["Order number"]))
    